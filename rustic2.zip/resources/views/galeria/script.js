const FullImgBox = document.getElementById("fullImgBox"),
fullImg = doicument.getElementById("fullimg");

function closeImg(){
    FullImgBox.style.display = "none";
}
