<footer class="copyright">
    <div class="grupo-2">
        <small>&copy; 2022, <b>Rustic MG</b> - Todos los derechos reservados.</small>
    </div>
</footer>
