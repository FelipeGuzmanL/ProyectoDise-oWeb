<footer class="pie-pagina">
    <div class="grupo-1">
      <div class="box2">
        <figure>
          <a href="/">
            <img src="/images/logo.jfif" alt="Logo Rustic MG">
          </a>
        </figure>
      </div>
      <div class="box2">
        <h2>SOBRE NOSOTROS</h2>
        <p>Somos una empresa dedicada a crear espacios soñados de tu hogar que valora la importancia de lo inmobiliario dentro y fuera de tu hogar a través de la fabricación de muebles  rústicos y vintage productos de diseño y decoración personalizada creando arte en los muebles para nuestros cliente.</p>
      </div>
      <div class="box2">
        <h2>SIGUENOS</h2>
        <div class="red-social">
          <a href="https://www.facebook.com/people/rustic_mg/100081050527630/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a>
          <a href="https://www.instagram.com/rustic_mg/?utm_medium=copy_link&hl=es-la" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <div class="grupo-2">
      <small>&copy; 2022, <b>Rustic MG</b> - Todos los derechos reservados.</small>
    </div>
</footer>

