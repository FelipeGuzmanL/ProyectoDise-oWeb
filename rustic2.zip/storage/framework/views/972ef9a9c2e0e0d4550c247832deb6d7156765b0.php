<?php $__env->startSection('content'); ?>
<section class="d-flex justify-content-center">
    <div class="class"card col-md-2 p-3"">
        <div class="titulo text-center">
            <h1>Iniciar Sesión</h1>
        </div>
        <div class="login">
            <form method="POST" action="">
                <div style="text-align: center">
                <?php echo csrf_field(); ?>
                    <input type="email" class="campo focus" placeholder="Email" id="email" name="email">
                    <input type="password" class="campo" placeholder="Contraseña" id="password" name="password">
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="p-2 mb-2 bg-danger text-white rounded">Usuario o Contraseña incorrectos</p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="suybmit" class="btn btn-primary">Log In</button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php echo $__env->make('copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoDise-oWeb\resources\views/auth/login.blade.php ENDPATH**/ ?>