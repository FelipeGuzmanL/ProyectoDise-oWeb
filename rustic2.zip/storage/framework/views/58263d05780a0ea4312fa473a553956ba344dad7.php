<?php $__env->startSection('content'); ?>
<!--<section class="d-flex justify-content-center">
    <div class="card col-md-5 p-5">
        <div class="mb-3">
            <h4>Envía tu diseño</h4>
        </div>
        <div class="flex position-relative">
            <form action="" method="POST" class="" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="titulo" class="form-label">Título</label>
                    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Título Publicación">
                    <?php if($errors->has('titulo')): ?>
                        <p class="p-2 mb-2 bg-danger text-white rounded"><?php echo e($errors->first('titulo')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                    <?php if($errors->has('descripcion')): ?>
                        <p class="p-2 mb-2 bg-danger text-white rounded"><?php echo e($errors->first('descripcion')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="boton">
                    <input type="file" class="text-lg" accept="image/*" name="imagenes"> <br><br>
                    <?php if($errors->has('imagenes')): ?>
                        <p class="p-2 mb-2 bg-danger text-white rounded"><?php echo e($errors->first('imagenes')); ?></p>
                    <?php endif; ?>
                    <input type="submit" class="btn btn-primary" value="Subir">
                </div>

            </form>
         </div>
    </div>
</section>-->

<div class="container-form2">
    <form action="" method="POST" class="" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" class="campo" id="titulo" name="titulo" placeholder="Título Publicación">
        <?php if($errors->has('titulo')): ?>
            <p class="p-2 mb-2 bg-danger text-white rounded"><?php echo e($errors->first('titulo')); ?></p>
        <?php endif; ?>
        <textarea type="text" class="campo" id="descripcion" name="descripcion" placeholder="Mensaje"></textarea>
        <?php if($errors->has('descripcion')): ?>
                <p class="p-2 mb-2 bg-danger text-white rounded"><?php echo e($errors->first('descripcion')); ?></p>
        <?php endif; ?>
        <input type="file" class="text-lg" accept="image/*" name="imagenes"> <br><br>
        <?php if($errors->has('imagenes')): ?>
            <p class="p-2 mb-2 bg-danger text-white rounded"><?php echo e($errors->first('imagenes')); ?></p>
        <?php endif; ?>
        <input type="submit" class="btn btn-primary" value="Subir">
    </form>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoDise-oWeb\resources\views/galeria/create.blade.php ENDPATH**/ ?>