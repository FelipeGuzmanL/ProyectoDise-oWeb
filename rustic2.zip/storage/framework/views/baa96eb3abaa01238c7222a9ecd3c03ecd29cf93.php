<?php $__env->startSection('content'); ?>

    <h1>Galería de Diseños</h1>
    <div class="galeria-img">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#image<?php echo e($row->id); ?>"><img class="img-fluid rounded img-thumbnail" src="images/<?php echo e($row->imagenes); ?>" alt="Image"></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="light-box" id="image<?php echo e($item->id); ?>">
            <a href="#image<?php echo e($item->id-1); ?>" class="next"><i class="fa-solid fa-arrow-left"></i></a>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $imagenes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i<=0): ?>
                    <img src="images/<?php echo e($item->imagenes); ?>" alt="">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="#image<?php echo e($item->id+1); ?>" class="next"><i class="fa-solid fa-arrow-right"></i></a>
            <a href="#" class="close">X</a>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoDise-oWeb\resources\views/galeria/index.blade.php ENDPATH**/ ?>